import { Button } from "@/components/ui/button";
import {ChevronRight, Music, Sparkles, Gift, Menu} from "lucide-react";
import { useState } from "react";

/**
 * Design Philosophy: Maximalist Luxury with Kinetic Energy
 * - Dark foundation (#0a0a0a) with strategic gold (#d4af37) and crimson (#8b1a1a) accents
 * - Asymmetric layouts with generous whitespace
 * - Kinetic animations responding to user interaction and scroll
 * - Playfair Display for bold, elegant typography
 * - Glowing effects reinforcing premium, tech-forward brand
 * 
 * Content Focus: Music Generation Prompts for AI Tools (Suno, Udio, Riffusion)
 * - Main Book: The Prompt Architect
 * - 2 Free Bonus Books: The Seduction Protocols + Blueprint (1000 prompts)
 * - Optional Add-on: Blueprint Two (500 prompts)
 * - Total: 2500+ prompts across 4 books
 */

export default function Home() {
  // Track which book card is currently focused or hovered. When defined,
  // the corresponding overlay will stay visible even on keyboard focus. This
  // improves accessibility by allowing users to read the description without
  // relying solely on hover interactions.
  const [activeBookId, setActiveBookId] = useState<number | undefined>(undefined);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const books = [
    {
      id: 1,
      title: "The Prompt Architect",
      subtitle: "The Award-Winning AI Music Prompt Book",
      description:
        "The definitive guide to AI music generation. Complete with sound design blueprints, artist/label references, advanced production techniques, and comprehensive genre coverage for Suno, Udio, and Riffusion.",
      image:
        "https://private-us-east-1.manuscdn.com/sessionFile/0fH79gzfy4TJbQezrqRkR9/sandbox/k6PucwPRGQFF5DdHX23uek-img-1_1771991600000_na1fn_Ym9vay0xLXByb21wdC1hcmNoaXRlY3Q.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvMGZINzlnemZ5NFRKYlFlenJxUmtSOS9zYW5kYm94L2s2UHVjd1BSR1FGRjVEZEhYMjN1ZWstaW1nLTFfMTc3MTk5MTYwMDAwMF9uYTFmbl9Ym9vay0xLXByb21wdC1hcmNoaXRlY3Q.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvMGZINzlnemZ5NFRKYlFlenJxUmtSOS9zYW5kYm94L2s2UHVjd1BSR1FGRjVEZEhYMjN1ZWstaW1nLTFfMTc3MTk5MTYwMDAwMF9uYTFmbl9Ym9vay0xLXByb21wdC1hcmNoaXRlY3Q.png",
      color: "from-blue-600 to-cyan-500",
      tag: "MAIN BOOK",
      isFeatured: true,
    },
    {
      id: 2,
      title: "The Seduction Protocols",
      subtitle: "Advanced Techniques & Experimental Fusion",
      description:
        "Advanced prompts covering erotic/experimental soundscapes, healing frequencies, binaural beats, and hybrid genre fusions. Includes neural lyric mutation engines and live performance templates.",
      image:
        "https://private-us-east-1.manuscdn.com/sessionFile/0fH79gzfy4TJbQezrqRkR9/sandbox/k6PucwPRGQFF5DdHX23uek-img-3_1771991604000_na1fn_Ym9vay0zLXNlZHVjdGlvbi1wcm90b2NvbHM.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvMGZINzlnemZ5NFRKYlFlenJxUmtSOS9zYW5kYm94L2s2UHVjd1BSR1FGRjVEZEhYMjN1ZWstaW1nLTNfMTc3MTk5MTYwNDAwMF9uYTFmbl9Ym9vay0zLXNlZHVjdGlvbi1wcm90b2NvbHM.png",
      color: "from-red-600 to-pink-600",
      tag: "FREE BONUS",
      isFeatured: false,
    },
    {
      id: 3,
      title: "Blueprint",
      subtitle: "1000 Production Templates & Prompts",
      description:
        "1000 specialized production prompts with complete templates covering arrangement, instrumentation, mixing, sound design, and live performance. The ultimate production reference.",
      image:
        "https://private-us-east-1.manuscdn.com/sessionFile/0fH79gzfy4TJbQezrqRkR9/sandbox/k6PucwPRGQFF5DdHX23uek-img-2_1771991596000_na1fn_Ym9vay0yLXByb21wdC12YXVsdA.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvMGZINzlnemZ5NFRKYlFlenJxUmtSOS9zYW5kYm94L2s2UHVjd1BSR1FGRjVEZEhYMjN1ZWstaW1nLTJfMTc3MTk5MTU5NjAwMF9uYTFmbl9Ym9vay0yLXByb21wdC12YXVsdA.png",
      color: "from-amber-600 to-red-600",
      tag: "FREE BONUS",
      isFeatured: false,
    },
  ];

  const bonusBook = {
    id: 4,
    title: "Blueprint Two",
    subtitle: "500 Advanced Production Techniques",
    description:
      "500 additional advanced production prompts and techniques. Expand your production toolkit with specialized templates for mixing, mastering, and experimental sound design.",
    image:
      "https://private-us-east-1.manuscdn.com/sessionFile/0fH79gzfy4TJbQezrqRkR9/sandbox/k6PucwPRGQFF5DdHX23uek-img-2_1771991596000_na1fn_Ym9vay0yLXByb21wdC12YXVsdA.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvMGZINzlnemZ5NFRKYlFlenJxUmtSOS9zYW5kYm94L2s2UHVjd1BSR1FGRjVEZEhYMjN1ZWstaW1nLTJfMTc3MTk5MTU5NjAwMF9uYTFmbl9Ym9vay0yLXByb21wdC12YXVsdA.png",
    tag: "OPTIONAL ADD-ON",
  };

  return (
    // Use a <main> element instead of a plain div so screen readers can jump
    // directly to the primary content. The id is referenced by the skip link.
    <main id="main-content" role="main" className="min-h-screen bg-background text-foreground overflow-hidden">
      {/* Skip navigation link for keyboard users */}
      <a href="#main-content" className="sr-only focus:not-sr-only absolute left-0 top-0 m-2 z-50 bg-accent text-accent-foreground px-3 py-1 rounded">Skip to main content</a>
      {/* Navigation */}
      <nav role="navigation" className="fixed top-0 w-full z-50 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="text-2xl font-display font-bold text-accent glow-gold flex items-center gap-2">
            <Music aria-hidden="true" className="w-6 h-6" />
            The Prompt Architect
          </div>
          <button
            className="md:hidden inline-flex items-center justify-center p-2 rounded-md hover:bg-accent/10 focus:outline-none focus:ring-2 focus:ring-ring"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label={mobileMenuOpen ? 'Close menu' : 'Open menu'}
          >
            <Menu aria-hidden="true" className="w-6 h-6" />
          </button>
          <div className={`${mobileMenuOpen ? "flex" : "hidden"} md:flex gap-4 md:gap-8 flex-col md:flex-row absolute md:static top-16 right-4 md:right-0 bg-background border border-border rounded-md md:rounded-none p-4 md:p-0`}>
            <a href="#books" className="hover:text-accent transition-colors">
              Books
            </a>
            <a href="#features" className="hover:text-accent transition-colors">
              Features
            </a>
            <a href="#about" className="hover:text-accent transition-colors">
              About
            </a>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center pt-20 overflow-hidden">
        {/* Background Image */}
        <div
          className="absolute inset-0 z-0"
          style={{
            backgroundImage:
              "url('https://private-us-east-1.manuscdn.com/sessionFile/0fH79gzfy4TJbQezrqRkR9/sandbox/k6PucwPRGQFF5DdHX23uek-img-4_1771991600000_na1fn_aGVyby1iYWNrZ3JvdW5k.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvMGZINzlnemZ5NFRKYlFlenJxUmtSOS9zYW5kYm94L2s2UHVjd1BSR1FGRjVEZEhYMjN1ZWstaW1nLTRfMTc3MTk5MTYwMDAwMF9uYTFmbl9hR1Z5YnkxaVlXTnJaM0p2ZFc1ay5wbmc~eC1vc3MtcHJvY2Vzcz1pbWFnZS9yZXNpemUsd18xOTIwLGhfMTkyMC9mb3JtYXQsd2VicC9xdWFsaXR5LHFfODAiLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=qd7Z3t3Wz7DXmgW1BNuO8IS6zrEDHNma97p2zzfwbD0pL7RzJA4hNUHgLzaDW~bEkJ-jMvbzS9MZ4cG-ez2zorXHuC9G1OxQQhWtvbnbZnwgHk22bUBNaw2ougMcEzG7eoatoji2EanCeepoGgYPrp5H08FoKiov92QMmXgcKtNQVo8STJyzIM3yKJ8vMXkTDRmzxJhXeXi7STvb8z-jrjDDG2A8or1x1Iyi2eIJpBMQqq0FPjnvtBjJoiDkd2EqTW4lulPI9RuTwKCSkVelQjrth3e~mvt1L0hWhDfbDs6AA1HuxrvmjpYwZnsZZUYw~BDK5vzC24ARkMeHOndN4w__')",
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
        >
          {/* Overlay */}
          <div className="absolute inset-0 bg-gradient-to-b from-background/40 via-background/60 to-background"></div>
        </div>

        {/* Content */}
        <div className="relative z-10 container mx-auto px-4 text-center max-w-4xl animate-fade-in-up">
          <div className="mb-6 inline-flex items-center gap-2 px-4 py-2 rounded-full border border-accent/30 bg-accent/5">
            <Sparkles aria-hidden="true" className="w-4 h-4 text-accent" />
            <span className="text-sm text-accent font-medium">
              2500+ Prompts for AI Music Generation
            </span>
          </div>

          <h1 className="text-display-xl mb-6 text-accent glow-gold">
            The Prompt Architect
          </h1>

          <p className="text-xl text-foreground/80 mb-4 max-w-2xl mx-auto leading-relaxed">
            The Award-Winning AI Music Prompt Book
          </p>

          <p className="text-lg text-foreground/70 mb-8 max-w-2xl mx-auto leading-relaxed">
            Master AI music generation with expertly-crafted prompts for Suno, Udio, and Riffusion. Get The Prompt Architect plus 2 free bonus books: The Seduction Protocols and Blueprint (1000 prompts). Optional: Add Blueprint Two for advanced techniques.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              className="bg-accent text-accent-foreground hover:bg-accent/90 text-base font-semibold"
            >
              Get The Complete Bundle
              <ChevronRight className="w-5 h-5 ml-2" />
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-accent text-accent hover:bg-accent/10"
            >
              Learn More
            </Button>
          </div>
        </div>
      </section>

      {/* Books Showcase Section */}
      <section id="books" className="py-24 bg-gradient-luxury">
        <div className="container mx-auto px-4">
          <div className="text-center mb-20 animate-fade-in">
            <h2 className="text-display-lg text-accent mb-4 glow-gold">
              Your Complete Collection
            </h2>
            <p className="text-lg text-foreground/70 max-w-2xl mx-auto">
              Get the main book plus 2 free bonus books. Optionally add Blueprint Two for even more advanced techniques.
            </p>
          </div>

          {/* Main Books Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            {books.map((book, index) => (
              <div
                key={book.id}
                id={`book-${book.id}`}
                className="group animate-fade-in relative focus:outline-none"
                style={{ animationDelay: `${index * 100}ms` }}
                // Make card focusable and accessible via keyboard. When focused or hovered
                // set the active book id so the overlay stays visible.
                tabIndex={0}
                role="button"
                onMouseEnter={() => setActiveBookId(book.id)}
                onMouseLeave={() => setActiveBookId(undefined)}
                onFocus={() => setActiveBookId(book.id)}
                onBlur={() => setActiveBookId(undefined)}
              >
                {/* Tag Badge */}
                <div className="absolute top-4 right-4 z-20 bg-accent text-accent-foreground px-3 py-1 rounded-full text-xs font-bold">
                  {book.tag}
                </div>

                <div className="relative h-96 rounded-lg overflow-hidden border border-border hover-glow transition-glow">
                  {/* Book Cover */}
                  <img
                    loading="lazy"
                    src={book.image}
                    alt={book.title}
                    // Provide multiple resolutions for responsive loading. Replace the size parameters
                    // in the URL to generate smaller images for smaller viewports.
                    srcSet={`${book.image.replace(/w_1920,h_1920/, 'w_640,h_640')} 640w, ${book.image.replace(/w_1920,h_1920/, 'w_1280,h_1280')} 1280w, ${book.image} 1920w`}
                    sizes="(min-width: 768px) 33vw, 100vw"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />

                  {/* Overlay: visible on hover or when the card is active via keyboard focus */}
                  <div
                    className={`absolute inset-0 bg-gradient-to-t from-background via-background/20 to-transparent flex flex-col justify-end p-6 transition-opacity duration-300 ${activeBookId === book.id ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`}
                  >
                    <h3 className="text-2xl font-display font-bold text-accent mb-2">
                      {book.title}
                    </h3>
                    <p className="text-sm text-foreground/80 mb-4">
                      {book.description}
                    </p>
                    <Button className="w-full bg-accent text-accent-foreground hover:bg-accent/90">
                      Learn More
                    </Button>
                  </div>
                </div>

                {/* Book Info */}
                <div className="mt-4">
                  <h3 className="text-xl font-display font-semibold text-foreground mb-1">
                    {book.title}
                  </h3>
                  <p className="text-sm text-accent font-medium">{book.subtitle}</p>
                  {/* Provide a persistent link to detailed information so users on touch devices can access details without relying on hover. */}
                  <a href={`#book-${book.id}`} className="mt-2 inline-block text-sm text-accent hover:underline focus:underline focus:outline-none">
                    Learn more
                  </a>
                </div>
              </div>
            ))}
          </div>

          {/* Optional Add-On Section */}
          <div className="mt-20 pt-20 border-t border-border">
            <div className="text-center mb-12 animate-fade-in">
              <h3 className="text-display-md text-accent mb-4 glow-gold">
                Expand Your Toolkit
              </h3>
              <p className="text-lg text-foreground/70 max-w-2xl mx-auto">
                Already have the complete bundle? Add Blueprint Two for 500 more advanced production techniques.
              </p>
            </div>

            <div className="max-w-2xl mx-auto">
            <div
                id={`book-${bonusBook.id}`}
                className="group animate-fade-in relative focus:outline-none"
                tabIndex={0}
                role="button"
                onMouseEnter={() => setActiveBookId(bonusBook.id)}
                onMouseLeave={() => setActiveBookId(undefined)}
                onFocus={() => setActiveBookId(bonusBook.id)}
                onBlur={() => setActiveBookId(undefined)}
              >
                {/* Tag Badge */}
                <div className="absolute top-4 right-4 z-20 bg-secondary text-secondary-foreground px-3 py-1 rounded-full text-xs font-bold">
                  {bonusBook.tag}
                </div>

                <div className="relative h-80 rounded-lg overflow-hidden border border-border hover-glow transition-glow">
                  {/* Book Cover */}
                  <img
                    loading="lazy"
                    src={bonusBook.image}
                    alt={bonusBook.title}
                    srcSet={`${bonusBook.image.replace(/w_1920,h_1920/, 'w_640,h_640')} 640w, ${bonusBook.image.replace(/w_1920,h_1920/, 'w_1280,h_1280')} 1280w, ${bonusBook.image} 1920w`}
                    sizes="(min-width: 768px) 50vw, 100vw"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />

                  {/* Overlay: visible on hover or when the card is active via keyboard focus */}
                  <div
                    className={`absolute inset-0 bg-gradient-to-t from-background via-background/20 to-transparent flex flex-col justify-end p-6 transition-opacity duration-300 ${activeBookId === bonusBook.id ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`}
                  >
                    <h3 className="text-2xl font-display font-bold text-accent mb-2">
                      {bonusBook.title}
                    </h3>
                    <p className="text-sm text-foreground/80 mb-4">
                      {bonusBook.description}
                    </p>
                    <Button className="w-full bg-accent text-accent-foreground hover:bg-accent/90">
                      Add to Order
                    </Button>
                  </div>
                </div>

                {/* Book Info */}
                <div className="mt-4">
                  <h3 className="text-xl font-display font-semibold text-foreground mb-1">
                    {bonusBook.title}
                  </h3>
                  <p className="text-sm text-accent font-medium">{bonusBook.subtitle}</p>
                  {/* Provide persistent link for optional add-on */}
                  <a href={`#book-${bonusBook.id}`} className="mt-2 inline-block text-sm text-accent hover:underline focus:underline focus:outline-none">
                    Learn more
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* Bundle Offer */}
          <div
            id="bundle"
            className="mt-20 p-8 md:p-12 rounded-lg border-2 border-accent bg-gradient-to-br from-accent/5 to-secondary/5 glow-accent animate-fade-in"
          >
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <div className="flex items-center gap-3 mb-4">
                  <Gift aria-hidden="true" className="w-8 h-8 text-accent" />
                  <h3 className="text-display-md text-accent glow-gold">
                    The Complete Bundle
                  </h3>
                </div>
                <p className="text-lg text-foreground/80 mb-6 leading-relaxed">
                  Everything you need to master AI music generation. Get the main book plus 2 free bonus books with 2500+ prompts total.
                </p>

                <ul className="space-y-3 mb-8">
                  <li className="flex items-start gap-3">
                    <span className="text-accent mt-1">✓</span>
                    <span className="text-foreground/80">
                      <strong>The Prompt Architect</strong> — Complete AI music generation guide
                    </span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent mt-1">✓</span>
                    <span className="text-foreground/80">
                      <strong>The Seduction Protocols</strong> — Advanced experimental techniques (FREE)
                    </span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent mt-1">✓</span>
                    <span className="text-foreground/80">
                      <strong>Blueprint</strong> — 1000 production templates (FREE)
                    </span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-accent mt-1">✓</span>
                    <span className="text-foreground/80">
                      Optional: <strong>Blueprint Two</strong> — 500 advanced techniques
                    </span>
                  </li>
                </ul>

                <Button asChild size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90">
                  <a href="/#bundle" className="inline-flex items-center">
                    Get Started Now
                    <ChevronRight className="w-5 h-5 ml-2" />
                  </a>
                </Button>
              </div>

              {/* Bundle Visual */}
              <div className="relative h-96 rounded-lg overflow-hidden">
                <img
                    loading="lazy"
                  src="https://private-us-east-1.manuscdn.com/sessionFile/0fH79gzfy4TJbQezrqRkR9/sandbox/k6PucwPRGQFF5DdHX23uek-img-5_1771991590000_na1fn_YWJzdHJhY3QtcGF0dGVybg.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvMGZINzlnemZ5NFRKYlFlenJxUmtSOS9zYW5kYm94L2s2UHVjd1BSR1FGRjVEZEhYMjN1ZWstaW1nLTVfMTc3MTk5MTU5MDAwMF9uYTFmbl9ZV0p6ZEhKaFkzUXRjR0YwZEdWeWJnLnBuZz94LW9zcy1wcm9jZXNzPWltYWdlL3Jlc2l6ZSx3XzE5MjAsaF8xOTIwL2Zvcm1hdCx3ZWJwL3F1YWxpdHkscV84MCIsIkNvbmRpdGlvbiI6eyJEYXRlTGVzc1RoYW4iOnsiQVdTOkVwb2NoVGltZSI6MTc5ODc2MTYwMH19fV19&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=JpEHGz8fztdFXhtzkqgGfk3i9YuTF4KhYMR~JJ7PEFtWtarO4~EJZzOf2E4sBrB7r-k2-y449HZ29Uz7gEpBTbQgRC2u5iRKwSCxW8HKl~RnXG3sWm8cFz-tCgUczVANcCBYrFhSszus8~oEAOBMf4glw0hmQIVXoTje~unH6S77JppZG~9c2V9w1GnzXHFJdPjuS82IKnDStjg3RbD9mqjKc9IF5b8ETNLYyqOGcu1ORuC~t0STKac9sc29MzBFnN4cam4UkdTHalykPDfwZgUzjX66DcSdSmUlbfPGqV57e4U5FjMaXLormQxMkeCUJw1LfioCv9YqZabgmUnURQ__"
                  alt="Abstract pattern"
                  srcSet="
                    https://private-us-east-1.manuscdn.com/sessionFile/0fH79gzfy4TJbQezrqRkR9/sandbox/k6PucwPRGQFF5DdHX23uek-img-5_1771991590000_na1fn_YWJzdHJhY3QtcGF0dGVybg.png?x-oss-process=image/resize,w_640,h_640/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvMGZINzlnemZ5NFRKYlFlenJxUmtSOS9zYW5kYm94L2s2UHVjd1BSR1FGRjVEZEhYMjN1ZWstaW1nLTVfMTc3MTk5MTU5MDAwMF9uYTFmbl9ZV0p6ZEhKaFkzUXRjR0YwZEdWeWJnLnBuZz94LW9zcy1wcm9jZXNzPWltYWdlL3Jlc2l6ZSx3XzY0MCxoXzY0MC9mb3JtYXQsd2VicC9xdWFsaXR5LHFfODAiLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=L1iN8IDCR1hfbHEugbEp4Cz0NkPUwFMnn7NtkFZlhADekQHpjEpwr3YiZ9VMW1CSfxcL8bDYPXhnKt6sPOzagcZ1owI4Ao1flnOKQBTi0OYmpTavJm9TUxK2k7iA5oHJMGSqiiYo5hgsud2KFKnMT7prbPiJXMGHuFneP7KYfE8aV02KAoSvwmdPa45tdkX4FZyHMm2qNOU0qYUPjw8MtwT9m7qDWCTOB6fw9JuINaNva8yXcV7F8spr0aEzIaOqEyxfpQt3RBkO2s8asaiRUxozg9SA6xuLuOgxhGxuC2TTfZgp9kYYjbsFlRgPl-fVCrPcFG7Gg95u7HLVMNunRg__ 640w,
                    https://private-us-east-1.manuscdn.com/sessionFile/0fH79gzfy4TJbQezrqRkR9/sandbox/k6PucwPRGQFF5DdHX23uek-img-5_1771991590000_na1fn_YWJzdHJhY3QtcGF0dGVybg.png?x-oss-process=image/resize,w_1280,h_1280/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvMGZINzlnemZ5NFRKYlFlenJxUmtSOS9zYW5kYm94L2s2UHVjd1BSR1FGRjVEZEhYMjN1ZWstaW1nLTVfMTc3MTk5MTU5MDAwMF9uYTFmbl9ZV0p6ZEhKaFkzUXRjR0YwZEdWeWJnLnBuZz94LW9zcy1wcm9jZXNzPWltYWdlL3Jlc2l6ZSx3XzEyODAsaF8xMjgwL2Zvcm1hdCx3ZWJwL3F1YWxpdHkscV84MCIsIkNvbmRpdGlvbiI6eyJEYXRlTGVzc1RoYW4iOnsiQVdTOkVwb2NoVGltZSI6MTc5ODc2MTYwMH19fV19&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=ErMtkmlpihguTBmsSH-UttmFtvkBjgfceGdKAH8LzpuTsIz9ouNT83yae77UxoJ0-Qt2q1iDq7v4lgyUt61SJ9-lGqC~BJvJ8EPDs-tHuoyTANPK0SWIv23bwU4Oy05OQcaJ9Hb-vJ9q37AhPSGefTHgkbvPtVFWa-5c2hpgJHj1As7bz87UsktIa2y9k6GgRCD4gUrqQXHHdENfPNDboKq49fb2VUJ4PpDJ59poICfPSTU1MIJ4w~S4cHwta3gn7fVPDH64XCtRUDExEIc49bzlLRrOMqQT-Gk1kzExOhiZqnnhucJ0a~R1kxtNDDDzAbRf5bYaOefOCVBB2VQeIg__ 1280w,
                    https://private-us-east-1.manuscdn.com/sessionFile/0fH79gzfy4TJbQezrqRkR9/sandbox/k6PucwPRGQFF5DdHX23uek-img-5_1771991590000_na1fn_YWJzdHJhY3QtcGF0dGVybg.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvMGZINzlnemZ5NFRKYlFlenJxUmtSOS9zYW5kYm94L2s2UHVjd1BSR1FGRjVEZEhYMjN1ZWstaW1nLTVfMTc3MTk5MTU5MDAwMF9uYTFmbl9ZV0p6ZEhKaFkzUXRjR0YwZEdWeWJnLnBuZz94LW9zcy1wcm9jZXNzPWltYWdlL3Jlc2l6ZSx3XzE5MjAsaF8xOTIwL2Zvcm1hdCx3ZWJwL3F1YWxpdHkscV84MCIsIkNvbmRpdGlvbiI6eyJEYXRlTGVzc1RoYW4iOnsiQVdTOkVwb2NoVGltZSI6MTc5ODc2MTYwMH19fV19&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=JpEHGz8fztdFXhtzkqgGfk3i9YuTF4KhYMR~JJ7PEFtWtarO4~EJZzOf2E4sBrB7r-k2-y449HZ29Uz7gEpBTbQgRC2u5iRKwSCxW8HKl~RnXG3sWm8cFz-tCgUczVANcCBYrFhSszus8~oEAOBMf4glw0hmQIVXoTje~unH6S77JppZG~9c2V9w1GnzXHFJdPjuS82IKnDStjg3RbD9mqjKc9IF5b8ETNLYyqOGcu1ORuC~t0STKac9sc29MzBFnN4cam4UkdTHalykPDfwZgUzjX66DcSdSmUlbfPGqV57e4U5FjMaXLormQxMkeCUJw1LfioCv9YqZabgmUnURQ__ 1920w
                  "
                  sizes="(min-width: 1024px) 50vw, 100vw"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-20 animate-fade-in">
            <h2 className="text-display-lg text-accent mb-4 glow-gold">
              What's Inside
            </h2>
            <p className="text-lg text-foreground/70 max-w-2xl mx-auto">
              Comprehensive resources for every type of music creator
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                title: "Genre Mastery",
                description:
                  "Comprehensive prompts covering hip-hop, rock, country, blues, electronic, and experimental fusion styles. Each with specific production notes and instrumentation guidance.",
                icon: "🎵",
              },
              {
                title: "Production Templates",
                description:
                  "1000+ complete production blueprints with arrangement, instrumentation, mixing, and FX chains. Ready-to-deploy starting points for professional tracks.",
                icon: "🎛️",
              },
              {
                title: "Artist Blueprints",
                description:
                  "Iconic sound signatures from legendary artists and labels. Reference mixing chains and production techniques from industry leaders.",
                icon: "🎤",
              },
              {
                title: "Advanced Techniques",
                description:
                  "Neural lyric mutation engines, live performance templates, chaos music theory, and AI-driven arrangement systems for next-level productions.",
                icon: "⚡",
              },
              {
                title: "Sound Design",
                description:
                  "Complete mixing chains, FX processing notes, and production blueprints. Mixing cheat sheets and reference materials for every genre.",
                icon: "✨",
              },
              {
                title: "AI Tool Integration",
                description:
                  "Optimized prompts for Suno, Udio, and Riffusion. Learn how to generate, refine, and integrate AI music into your workflow.",
                icon: "🤖",
              },
            ].map((feature, index) => (
              <div
                key={index}
                className="p-6 rounded-lg border border-border bg-card hover-glow transition-glow animate-fade-in"
                style={{ animationDelay: `${index * 50}ms` }}
              >
                {/* Use a span with role=img and aria-label to convey the emoji meaning to screen readers */}
                <span
                  role="img"
                  aria-label={`${feature.title} icon`}
                  className="text-4xl mb-4"
                >
                  {feature.icon}
                </span>
                <h3 className="text-xl font-display font-semibold text-foreground mb-2">
                  {feature.title}
                </h3>
                <p className="text-foreground/70">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Creator Types Section */}
      <section id="about" className="py-24 bg-gradient-luxury">
        <div className="container mx-auto px-4">
          <div className="text-center mb-20 animate-fade-in">
            <h2 className="text-display-lg text-accent mb-4 glow-gold">
              For Every Creator
            </h2>
            <p className="text-lg text-foreground/70 max-w-2xl mx-auto">
              Whether you're a producer, songwriter, engineer, or AI enthusiast — these books are designed for you
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {[
              {
                role: "Producers",
                use: "Start or hybridize tracks using genre templates. Use instrumentation and sound design notes as production briefs.",
              },
              {
                role: "Songwriters",
                use: "Explore fresh lyric themes and arrangement ideas. Harness AI-assisted mutation strategies for unique compositions.",
              },
              {
                role: "Live Performers",
                use: "Apply performance layouts for improvisation and spontaneous genre-blending. Use neural sequencing blueprints for live AI integration.",
              },
              {
                role: "Engineers",
                use: "Reference mixing, panning, and FX chains throughout. Each genre includes specific processing and mastering notes.",
              },
              {
                role: "AI Enthusiasts",
                use: "Implement code structures and algorithms for generative song systems. Explore neural lyric mutation and adaptive performance.",
              },
              {
                role: "Music Educators",
                use: "Teach music theory through practical AI generation. Use prompts as teaching tools for genre study and production.",
              },
            ].map((item, index) => (
              <div
                key={index}
                className="p-6 rounded-lg border border-border bg-card hover-glow transition-glow animate-fade-in"
                style={{ animationDelay: `${index * 50}ms` }}
              >
                <h3 className="text-xl font-display font-semibold text-accent mb-3">
                  {item.role}
                </h3>
                <p className="text-foreground/70">{item.use}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-accent/10 via-secondary/10 to-accent/10 border-y border-border">
        <div className="container mx-auto px-4 text-center animate-fade-in">
          <h2 className="text-display-lg text-accent mb-6 glow-gold">
            Ready to Master AI Music Generation?
          </h2>
          <p className="text-lg text-foreground/80 mb-8 max-w-2xl mx-auto">
            Join thousands of producers, songwriters, and creators who are using The Prompt Architect to unlock their creative potential with AI music tools.
          </p>
          {/* Email capture form */}
          <form
            action="#"
            className="mb-8 max-w-md mx-auto flex flex-col sm:flex-row items-center gap-4"
            onSubmit={(e) => e.preventDefault()}
          >
            <input
              type="email"
              required
              placeholder="Enter your email for updates"
              aria-label="Email address"
              className="flex-1 px-4 py-2 border border-border rounded-md bg-background text-foreground placeholder-foreground/50 focus:outline-none focus:ring-2 focus:ring-accent"
            />
            <Button type="submit" className="bg-accent text-accent-foreground hover:bg-accent/90 px-6 py-2">
              Notify Me
            </Button>
          </form>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild
              size="lg"
              className="bg-accent text-accent-foreground hover:bg-accent/90 text-base font-semibold">
              <a href="/#bundle" className="inline-flex items-center">
                Get Started Today
                <ChevronRight className="w-5 h-5 ml-2" />
              </a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-accent text-accent hover:bg-accent/10"
            >
              View Sample Prompts
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-background border-t border-border py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-display font-bold text-accent mb-4 flex items-center gap-2">
                <Music aria-hidden="true" className="w-5 h-5" />
                The Prompt Architect
              </h4>
              <p className="text-foreground/70 text-sm">
                2500+ AI music generation prompts for Suno, Udio, and Riffusion. Master every genre and production technique.
              </p>
            </div>
            <div>
              <h5 className="font-semibold text-foreground mb-4">Books</h5>
              <ul className="space-y-2 text-sm text-foreground/70">
                <li>
                  <a href="#" className="hover:text-accent transition-colors">
                    The Prompt Architect
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-accent transition-colors">
                    The Seduction Protocols
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-accent transition-colors">
                    Blueprint
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h5 className="font-semibold text-foreground mb-4">Resources</h5>
              <ul className="space-y-2 text-sm text-foreground/70">
                <li>
                  <a href="#" className="hover:text-accent transition-colors">
                    AI Tools Guide
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-accent transition-colors">
                    Production Tips
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-accent transition-colors">
                    Community
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h5 className="font-semibold text-foreground mb-4">Legal</h5>
              <ul className="space-y-2 text-sm text-foreground/70">
                <li>
                  <a href="#" className="hover:text-accent transition-colors">
                    Privacy Policy
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-accent transition-colors">
                    Terms of Service
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-accent transition-colors">
                    Contact
                  </a>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-border pt-8 flex flex-col md:flex-row justify-between items-center text-sm text-foreground/60">
            <p>&copy; 2025 The Prompt Architect. All rights reserved.</p>
            <div className="flex gap-6 mt-4 md:mt-0">
              <a href="#" className="hover:text-accent transition-colors">
                Twitter
              </a>
              <a href="#" className="hover:text-accent transition-colors">
                Discord
              </a>
              <a href="#" className="hover:text-accent transition-colors">
                YouTube
              </a>
            </div>
          </div>
        </div>
      </footer>
    </main>
  );
}
